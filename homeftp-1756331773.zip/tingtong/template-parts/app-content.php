<div id="preloader">
        <div class="preloader-icon-container">
            <img src="https://pawelperfect.pl/wp-content/uploads/2025/07/output-onlinepngtools-1-1.png" alt="Ting Tong Logo" class="splash-icon">
        </div>
        <div class="preloader-content-container">
            <div class="language-selection">
                <h2>Wybierz Język / Select Language</h2>
                <div class="lang-buttons-container">
                    <button data-lang="pl"><span>Polski</span></button>
                    <button data-lang="en"><span>English</span></button>
                </div>
            </div>
        </div>
    </div>
    <!-- Szablon dla pojedynczego slajdu -->
    <template id="slide-template">
        <div class="webyx-section">
            <div class="tiktok-symulacja">
                <video class="videoPlayer" muted loop playsinline webkit-playsinline autoplay preload="metadata" poster="placeholder.jpg" oncontextmenu="return false;" crossorigin="anonymous">
                    <source src="" type="video/mp4" />
                    Twoja przeglądarka nie obsługuje wideo.
                </video>
                <div class="video-overlay-icon pause-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"></path></svg>
                </div>
                <div class="secret-overlay" aria-hidden="true">
                    <svg class="secret-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 00-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" /></svg>
                    <h2 class="secret-title" data-translate-key="secretTitle">Top Secret</h2>
                    <p class="secret-subtitle" data-translate-key="secretSubtitle">Log in to unlock</p>
                </div>
                <div class="topbar" data-view="default">
                    <button class="topbar-icon-btn hamburger-icon" data-action="toggle-main-menu" data-translate-aria-label="menuAriaLabel" aria-label="Menu"><svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M3 12h18M3 6h18M3 18h18"></path></svg></button>
                    <button class="topbar-central-trigger" data-action="toggle-login-panel"><div class="central-text-wrapper"><span class="topbar-text"></span></div></button>
                    <button class="topbar-icon-btn notification-bell" data-action="toggle-notifications" data-translate-aria-label="notificationAriaLabel" aria-label="Powiadomienia"><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M13.73 21a2 2 0 0 1-3.46 0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg><div class="notification-dot"></div></button>
                </div>
                <div class="login-panel" aria-hidden="true">
                    <!-- Content will be injected by JS -->
                </div>
                <div class="logged-in-menu" aria-hidden="true">
                    <a href="#" data-action="open-account-modal" class="accountMenuButton" data-translate-key="accountMenuButton">Konto</a>
                    <a href="#" data-action="logout" class="logout-link" data-translate-key="logoutLink">Wyloguj</a>
                </div>
                <div class="sidebar">
                    <div class="profile">
                        <button class="profileButton" data-action="subscribe" data-translate-alert="subscribeAlert" data-translate-aria-label="subscribeAriaLabel" aria-label="Subskrybuj"><img src="" alt="Profil" loading="lazy" decoding="async" /></button>
                        <div class="plus" aria-hidden="true">+</div>
                    </div>
                    <button class="icon-button like-button" data-action="toggle-like" data-like-id="" data-translate-alert="likeAlert" data-translate-aria-label="likeAriaLabel" aria-label="Polub" aria-pressed="false">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                        <div class="like-count icon-label">0</div>
                    </button>
                    <button class="icon-button commentsButton" data-action="open-comments-modal" aria-controls="commentsModal" data-translate-aria-label="commentsAriaLabel" aria-label="Komentarze">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>
                        </svg>
                    </button>
                    <button class="icon-button shareButton" data-action="share" data-translate-title="shareTitle" data-translate-aria-label="shareAriaLabel"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l6 6-6 6M21 11H9a6 6 0 0 0-6 6" /></svg><div class="icon-label" data-translate-key="shareText">Szeruj</div></button>
                    <button class="icon-button infoButton" data-action="open-info-modal" data-translate-title="infoTitle" data-translate-aria-label="infoAriaLabel" aria-controls="infoModal"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="16" height="16" /><line x1="8" y1="8" x2="16" y2="8" /><line x1="8" y1="12" x2="16" y2="12" /><line x1="8" y1="16" x2="12" y2="16" /></svg><div class="icon-label" data-translate-key="infoText">Info</div></button>
                    <button class="icon-button languageButton" data-action="toggle-language" data-translate-aria-label="languageAriaLabel">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" stroke-width="1.5" fill="none"/><line x1="2" y1="12" x2="22" y2="12" stroke-width="1.5"/><ellipse cx="12" cy="12" rx="4" ry="10" stroke-width="1.5" fill="none"/></svg>
                        <div class="icon-label language-label" data-translate-key="languageText">PL</div>
                    </button>
                    <button class="icon-button tipButton" data-action="show-tip-jar" data-translate-title="tipTitle" data-translate-aria-label="tipAriaLabel">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="7" width="20" height="12" rx="2" ry="2" /><path d="M2 10h20" /><circle cx="18" cy="13" r="2" /></svg>
                        <div class="icon-label" data-translate-key="tipText">Napiwek</div>
                    </button>
                </div>
                <div class="bottombar">
                    <div class="video-progress" tabindex="0" role="slider" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="Postęp wideo">
                        <div class="progress-line"></div>
                        <div class="progress-dot"></div>
                    </div>
                    <div class="text-info">
                        <div class="text-user"></div>
                        <div class="text-description"></div>
                    </div>
                </div>
            </div>
        </div>
    </template>
    <!-- Główny kontener na slajdy -->
    <div id="webyx-container"></div>
    <!-- Współdzielone Modale i Alerty -->
    <div id="alertBox" role="status" aria-live="polite">
        <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" style="width:18px; height:18px; stroke:white; stroke-width:2; fill:none; margin-right:6px;"><path d="M6 10V8a6 6 0 1 1 12 0v2" /><rect x="4" y="10" width="16" height="10" rx="2" ry="2" /></svg>
        <span id="alertText"></span>
    </div>
    <div id="infoModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="infoTitle" aria-hidden="true">
        <div class="modal-content" tabindex="-1">
            <button class="modal-close-btn" data-translate-aria-label="closeInfoAriaLabel" aria-label="Zamknij informacje">&times;</button>
            <h2 id="infoTitle" data-translate-key="infoModalTitle">Informacje</h2>
            <div class="modal-body">
                <p data-translate-key="infoModalBodyP1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in dui mauris. Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor.</p>
                <p data-translate-key="infoModalBodyP2">Ut in nulla enim. Phasellus molestie magna non est bibendum non venenatis nisl tempor. Suspendisse dictum feugiat nisl ut dapibus. Mauris iaculis porttitor posuere. Praesent id metus massa, ut blandit odio.</p>
                <div class="tip-cta">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-2-9h4v2h-4v-2zm0 4h4v2h-4v-2zm-2-9.75c0-.41.34-.75.75-.75h2.5c.41 0 .75.34.75.75v3.5h-4v-3.5z"/></svg>
                    <p data-translate-key="infoModalBodyTip">Podoba Ci się? Zostaw napiwek i dołącz do grona patronów, aby wspierać rozwój aplikacji!</p>
                </div>
                <p data-translate-key="infoModalBodyP3">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.</p>
            </div>
        </div>
    </div>
    <div id="commentsModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="commentsTitle" aria-hidden="true">
        <div class="modal-content" tabindex="-1">
            <button class="modal-close-btn" data-translate-aria-label="closeCommentsAriaLabel" aria-label="Zamknij komentarze">&times;</button>
            <h2 id="commentsTitle" data-translate-key="commentsModalTitle">Komentarze</h2>
            <div class="modal-body">
                <!-- celowo pusto — przygotowane pod późniejszą integrację -->
            </div>
        </div>
    </div>

    <!-- Notification Popup -->
    <div class="notification-popup" id="notificationPopup" role="dialog" aria-modal="true" aria-labelledby="notification-title">
        <div class="notification-header">
            <strong id="notification-title" data-translate-key="notificationsTitle">Powiadomienia</strong>
            <button data-action="close-notifications" data-translate-aria-label="closeNotificationsAriaLabel" aria-label="Zamknij powiadomienia">&times;</button>
        </div>
        <ul class="notification-list">
            <div class="notification-empty-state hidden-by-js">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" /></svg>
                <p data-translate-key="notificationsEmpty">Wszystko na bieżąco!</p>
            </div>
            <!-- Notification items will be injected by JS -->
        </ul>
    </div>

    <!-- New Account Modal -->
    <div class="account-modal-overlay" id="accountModal">
        <div class="account-modal-content">
            <!-- Header -->
            <div class="account-header">
                <h2>Profil</h2>
                <button class="close-btn" data-action="close-account-modal">&times;</button>
            </div>

            <!-- Tabs -->
            <div class="account-tabs">
                <button class="tab-btn active" data-tab="profile">Profil</button>
                <button class="tab-btn" data-tab="password">Hasło</button>
                <button class="tab-btn" data-tab="delete">Usuń konto</button>
            </div>

            <!-- Content -->
            <div class="account-content">
                <!-- Profile Tab -->
                <div class="tab-pane active" id="profile-tab">
                    <!-- Avatar Wizytówka -->
                    <div class="avatar-section">
                        <div class="avatar-wrapper">
                            <div class="avatar-container">
                                <img src="" alt="Avatar" class="avatar-img" id="userAvatar">
                            </div>
                            <button class="avatar-edit-btn" id="avatarEditBtn" title="Zmień avatar">
                                +
                            </button>
                        </div>
                        <div class="avatar-info">
                            <div class="avatar-name" id="displayName"></div>
                            <div class="avatar-email" id="userEmail"></div>
                            <div class="user-badge">
                                <svg class="badge-icon" fill="currentColor" viewBox="0 0 24 24">
                                    <path d="M12 2L15.09 8.26L22 9L17 14L18.18 21L12 17.77L5.82 21L7 14L2 9L8.91 8.26L12 2Z"/>
                                </svg>
                                Patron
                            </div>
                        </div>
                    </div>

                    <!-- Formularz danych - Osobna ramka -->
                    <div class="form-section">
                        <h3 class="section-title">Dane osobowe</h3>

                        <form id="profileForm">
                            <div class="form-row">
                                <div class="form-group">
                                    <label class="form-label">Imię</label>
                                    <input type="text" class="form-input" placeholder="Twoje imię" id="firstName" value="">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Nazwisko</label>
                                    <input type="text" class="form-input" placeholder="Twoje nazwisko" id="lastName" value="">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-input" placeholder="email@domena.pl" id="email" value="">
                            </div>

                            <button type="submit" class="btn-primary" id="saveProfileBtn">
                                Zapisz zmiany
                            </button>
                            <div class="status-message status-success" id="profileSuccess">
                                Profil został zaktualizowany!
                            </div>
                            <div class="status-message status-error" id="profileError">
                                Wystąpił błąd podczas aktualizacji profilu.
                            </div>
                        </form>
                    </div>

                    <!-- Ustawienia - Trzecia ramka -->
                    <div class="settings-section">
                        <h3 class="section-title">Ustawienia</h3>

                        <!-- Zgoda na maile -->
                        <div class="toggle-container">
                            <label class="toggle-label">Zgoda na maile</label>
                            <div class="toggle-switch" id="emailConsent">
                                <div class="toggle-slider"></div>
                            </div>
                        </div>

                        <!-- Język maili -->
                        <div class="form-group">
                            <label class="form-label">Język maili</label>
                            <div class="language-selector">
                                <div class="language-option active" data-lang="pl">
                                    Polski
                                </div>
                                <div class="language-option" data-lang="en">
                                    English
                                </div>
                            </div>
                        </div>

                        <button type="button" class="btn-primary" id="saveSettingsBtn">
                            Zapisz ustawienia
                        </button>

                        <div class="status-message status-success" id="settingsSuccess">
                            Ustawienia zostały zapisane!
                        </div>
                        <div class="status-message status-error" id="settingsError">
                            Wystąpił błąd podczas zapisywania ustawień.
                        </div>
                    </div>
                </div>

                <!-- Password Tab -->
                <div class="tab-pane" id="password-tab">
                    <div class="profile-section">
                        <h3 class="section-title">Zmiana hasła</h3>

                        <form id="passwordForm">
                            <div class="form-group">
                                <label class="form-label">Obecne hasło</label>
                                <input type="password" class="form-input" placeholder="Wprowadź obecne hasło" id="currentPassword">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Nowe hasło</label>
                                <input type="password" class="form-input" placeholder="Minimum 8 znaków" id="newPassword">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Powtórz nowe hasło</label>
                                <input type="password" class="form-input" placeholder="Powtórz nowe hasło" id="confirmPassword">
                                <div class="helper-text">
                                    Hasło musi zawierać minimum 8 znaków. Zalecamy użycie liter, cyfr i znaków specjalnych.
                                </div>
                            </div>

                            <button type="submit" class="btn-primary" id="changePasswordBtn">
                                Zmień hasło
                            </button>
                             <div class="status-message status-success" id="passwordSuccess">
                                Hasło zostało zmienione!
                            </div>
                            <div class="status-message status-error" id="passwordError">
                                Wystąpił błąd podczas zmiany hasła.
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Delete Tab -->
                <div class="tab-pane" id="delete-tab">
                    <div class="profile-section">
                        <h3 class="section-title">Usuń konto</h3>

                        <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 12px; padding: 20px; margin-bottom: 24px;">
                            <h4 style="color: #ef4444; margin-bottom: 12px; font-size: 16px;">⚠️ Uwaga!</h4>
                            <p style="color: rgba(255, 255, 255, 0.8); font-size: 14px; line-height: 1.5;">
                                Ta operacja jest nieodwracalna. Wszystkie Twoje dane, filmy i ustawienia zostaną trwale usunięte.
                            </p>
                        </div>

                        <form id="deleteForm">
                            <div class="form-group">
                                <label class="form-label">Aby potwierdzić, wpisz: <strong>USUWAM KONTO</strong></label>
                                <input type="text" class="form-input" placeholder="USUWAM KONTO" id="deleteConfirmation">
                                <div class="helper-text">
                                    Po usunięciu konta zostaniesz automatycznie wylogowany.
                                </div>
                            </div>

                            <button type="submit" class="btn-danger" id="deleteAccountBtn" disabled>
                                Trwale usuń konto
                            </button>
                            <div class="status-message status-success" id="deleteSuccess">
                                Konto zostało usunięte. Trwa wylogowywanie...
                            </div>
                            <div class="status-message status-error" id="deleteError">
                                Wystąpił błąd podczas usuwania konta.
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Crop Modal -->
    <div class="crop-modal" id="cropModal">
        <div class="crop-container">
            <div class="crop-header">
                <h3 class="crop-title">Przytnij avatar</h3>
                <button class="crop-close" id="cropCloseBtn">&times;</button>
            </div>
            <div class="crop-stage">
                <canvas class="crop-canvas" id="cropCanvas" width="400" height="300"></canvas>
                <div class="crop-overlay"></div>
            </div>
            <div class="crop-controls">
                <button class="zoom-btn" id="zoomOutBtn">−</button>
                <input type="range" class="zoom-slider" id="zoomSlider" min="0.5" max="3" step="0.01" value="1">
                <button class="zoom-btn" id="zoomInBtn">+</button>
            </div>
            <div class="helper-text" style="margin-bottom: 20px; text-align: center;">
                Przeciągaj, aby pozycjonować. Użyj suwaka lub +/− aby przybliżyć.
            </div>
            <div class="crop-actions">
                <button class="btn-crop" id="cropSaveBtn">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    Zapisz avatar
                </button>
            </div>
        </div>
    </div>
    <!-- Hidden file input -->
    <input type="file" class="file-input" id="avatarFileInput" accept="image/*">
    <!-- Hidden containers for WordPress to render shortcodes -->
    <div id="um-login-render-container" style="display: none;"><?php echo do_shortcode('[tt_login_form]'); ?></div>
